REM Last command executed by GameFixer
REM Check if paths are correct
""D:\_NEXAPLAY\Steam-PerGame\Bypass Game\UnRAR.exe" x -p"adi83geel" -y -o+ "C:\Users\ADMIN\AppData\Local\Temp\GameFixer_1225560\unravel.rar" "D:\SteamLibrary\steamapps\common\Unravel" & PAUSE"
