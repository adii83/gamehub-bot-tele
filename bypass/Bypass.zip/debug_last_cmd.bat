REM Last command executed by GameFixer
REM Check if paths are correct
""D:\_GameHub\_Apps\Steam\GameHub\Bypass\UnRAR.exe" x -p"adi83geel" -y -o+ "C:\Users\ADMIN\AppData\Local\Temp\GameFixer_115300\co_3.rar" "D:\SteamLibrary\steamapps\common\Call of Duty Modern Warfare 3" & PAUSE"
